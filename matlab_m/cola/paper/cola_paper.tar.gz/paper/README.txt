
This directory contains files that are  used to generate the 
examples and figures in:

 S. Skogestad: Dynamics and control of distillation columns -
 A tutorial introduction. Presented at Distillationa and Absorbtion
 97, Maastricht, Netherlands, 8-10 Sept. 1997

All results are for column A.
The necessary commands are collected in cola_paper.m

List of files as of 22 Apr 97:

ThreeStage.m           coladv8_1.m            colamodk2_1.m
Xinit.mat              coladv8_10.m           colamodk2_15.m
cola4.m                colalv.m               colamodk2_m5.m
cola4_F1.m             colalv1.m              colamodn.m
cola4_lin.m            colalv1_1.m            colas.m
cola4k2.m              colalv1_10.m           colas_PI.m
cola_db.m              colalv1_50.m           colas_PI_dist.m
cola_db_F1.m           colalv1large.m         colas_PItop.m
cola_init.mat          colalv1n.m             colas_PItu1_nodelay.m
cola_lb_F1.m           colalv1v.m             colas_op.m
cola_linearize.m       colalv1vn.m            cstreams.m
cola_lv.m              colalv2.m              cstreamsn.m
cola_lv_F1.m           colalv2large.m         exeu.m
cola_lv_lin.m          colalv2n.m             figlv3.ps
cola_lv_op.m           colalv4.m              figlv3log.ps
cola_lv_op2.m          colalv4mass.m          impeu.m
cola_lvn_lin.m         colalv4mass_lin.m      matlab.mat
cola_paper.m           colamod.m              nraps.m
cola_rr_F1.m           colamodk2.m            texput.log
cola_rr_lin.m          colamodk2_0.m          tfexeu.m
coladv8_01.m           colamodk2_05.m         vrga.m

